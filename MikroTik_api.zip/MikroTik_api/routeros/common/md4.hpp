#ifndef MD4_HPP
#define MD4_HPP

#include <string>

namespace MD4
{
    std::string md4(std::string msg);
}

#endif
