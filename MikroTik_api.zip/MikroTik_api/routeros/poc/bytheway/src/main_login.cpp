#include <sstream>
#include <cstdlib>
#include <iostream>
#include <boost/cstdint.hpp>
#include <boost/program_options.hpp>

#include "winbox_session.hpp"
#include "winbox_message.hpp"
#include "md5.hpp"

bool try_login(const std::string& p_ip, const std::string& p_port,
                 const std::string& p_username, const std::string& p_password)
{
    Winbox_Session mproxy_session(p_ip, p_port);
    if (!mproxy_session.connect())
    {
        std::cerr << "[-] Failed to connect to the remote host" << std::endl;
        return false;
    }

    boost::uint32_t p_session_id = 0;
    if (!mproxy_session.login(p_username, p_password, p_session_id))
    {
        std::cerr << "[-] Login failed." << std::endl;
        return false;
    }

    std::cout << "[+] Login success " << std::endl;
    return true;
}

int main(int p_argc, const char** p_argv)
{
    std::string ip;
    std::string winbox_port = "8291";
    if (p_argc < 4)
    {
         std::cout << "[+] Using:./Winbox ip username password " << std::endl;
         return 3;
    }
    
    if (!try_login(p_argv[1], winbox_port, p_argv[2], p_argv[3]))
    {
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
 
